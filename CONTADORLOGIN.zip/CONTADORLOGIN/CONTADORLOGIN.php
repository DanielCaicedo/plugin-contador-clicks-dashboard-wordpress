<?php
/**
 * Plugin Name:   ContadorLogin
 * Plugin Author: Daniel Caicedo
 * Description:   Cuenta las veces que entran al dashboard de wordpress
 * Plugin URI:    
 * Version:       1.0.0
 * Author:        Hack Daniels
 * Author URI:    https://hack-daniels.com/
 *
 */

defined( 'ABSPATH' ) || die();

define( 'CONTADORLOGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CONTADORLOGIN_PLUGIN_FILE', __FILE__ );
define( 'CONTADORLOGIN_VERSION', '1.0.0' );

// Crea la tabla para los enlaces al activar el plugin.
require_once CONTADORLOGIN_DIR . 'include/create-table.php';
// Llama al fichero JavaScript que estará vigilando la pulsación de enlaces.
require_once CONTADORLOGIN_DIR . 'include/enqueue-scripts.php';
// Procesa la pulsación de un enlace mediante AJAX.
require_once CONTADORLOGIN_DIR . 'include/procesa-click.php';
// Panel administrativo para ver el contenido de la tabla en el escritorio.
require_once CONTADORLOGIN_DIR . 'include/admin-click-list.php';
// Shortcode para mostrar la lista de clicks en escritorio o en la web.
require_once CONTADORLOGIN_DIR . 'include/public-click-list.php';
